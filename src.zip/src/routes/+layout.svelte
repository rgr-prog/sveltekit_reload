<script lang="ts">
	import { beforeNavigate } from '$app/navigation';
	import type { LayoutLoad, LayoutData } from './$types';
	beforeNavigate(() => console.log('Raiz beforeNavigate'));

	export let data: LayoutData;

	console.log('Data visto no +layout.svelte da raiz: ', data.now_root);
</script>

<slot />
