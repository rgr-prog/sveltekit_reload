<script lang="ts">
	import { goto } from '$app/navigation';

	function goToLastRoute() {
		window.history.back(); // Volta para a última rota no histórico do navegador
	}
</script>

<p>Login</p>
<button on:click={goToLastRoute}>Voltar para a última rota</button>
