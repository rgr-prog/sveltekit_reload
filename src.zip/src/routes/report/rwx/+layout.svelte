<script>
	import { beforeNavigate } from '$app/navigation';
	beforeNavigate(() => console.log('RWX beforeNavigate'));
</script>

<slot />
