<script lang="ts">
	import { goto, invalidate, invalidateAll } from '$app/navigation';
	import { page } from '$app/state';
	import { onMount, tick } from 'svelte';
	import type { PageData } from './$types';
	export let data: PageData;

	$: if (data) {
		console.log('Agora o Line ve data:', JSON.stringify(data));
	}
	onMount(() => {});
	async function evaluateParams() {
		const currentUrl = page.url;
		const params = currentUrl.searchParams;
		params.set('ids', Date.now().toString());
		if (typeof window !== 'undefined') {
			await goto(`${currentUrl.pathname}?${params.toString()}`, {
				replaceState: true // não adiciona ao histórico do navegador
			});
		}
	}
	async function reload() {
		await invalidate('app:layout_root');
		console.log('Reload');
	}
</script>

<p>Line graph</p>
<ul>
	<li>
		<a href="/report/rwx/bar">Vá para Bar</a>
	</li>
	<li>
		<a href="/login">Vá para o login</a>
	</li>

	<li>
		<button on:click={() => evaluateParams()}>Evaluate</button>
	</li>
	<li>
		<button on:click={() => reload()}>Invalidade</button>
	</li>
</ul>
