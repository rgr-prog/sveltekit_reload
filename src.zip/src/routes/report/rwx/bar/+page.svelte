<script lang="ts">
	import { onMount } from 'svelte';

	onMount(() => {
		console.log('Cheguei no BAR');
	});
</script>

<p>BAR graph</p>
<a href="/report/rwx/line">Vá para Line</a>
