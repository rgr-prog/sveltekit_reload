<script>
	import { beforeNavigate } from '$app/navigation';
	beforeNavigate(() => console.log('Report beforeNavigate'));
</script>

<slot />
